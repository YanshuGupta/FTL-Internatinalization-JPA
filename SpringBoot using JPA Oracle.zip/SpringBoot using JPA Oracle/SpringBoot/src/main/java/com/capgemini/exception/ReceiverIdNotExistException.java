package com.capgemini.exception;

public class ReceiverIdNotExistException extends IdNotExistException {

}
