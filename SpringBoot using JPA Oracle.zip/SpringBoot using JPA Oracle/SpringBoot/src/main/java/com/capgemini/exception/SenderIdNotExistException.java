package com.capgemini.exception;

public class SenderIdNotExistException extends IdNotExistException {

}
